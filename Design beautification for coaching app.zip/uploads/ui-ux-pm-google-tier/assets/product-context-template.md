# Product context template

Fill this in for your product, then either:
1. Save it as `.claude/product-context.md` in your project root (the skill auto-discovers this), or
2. Save it as `docs/product-context.md` in your project root (the skill auto-discovers this too), or
3. Paste it inline at the start of any conversation with the skill.

The skill needs this to apply its filters. Without it, every spec it produces is a guess.

---

## Template

```markdown
# Product context — [PRODUCT NAME]

## One-liner
[Product name] is a [type of product] that [primary thing it does] for [primary user].

## Primary user
[Concrete description, not "users". Include: who they are, age range, location/market,
device habits, what they care about, what they'd be doing without your product.]

## Top 3 jobs-to-be-done (in user voice)
1. "When [situation], I want [motivation], so [outcome]."
2. "When [situation], I want [motivation], so [outcome]."
3. "When [situation], I want [motivation], so [outcome]."

## Current core flows
1. [Flow name]: [terse step-by-step, e.g. "tap device to phone (NFC) → app captures wifi
   + target plant → device syncs."]
2. [Flow name]: [...]
3. [Flow name]: [...]

## Current IA (information architecture)
- Primary tabs / surfaces: [list]
- Hidden in menus / settings: [list]
- Explicitly NOT in IA: [list]

## North Star metric
[One single measurable number that captures value delivered. Target value if known.]

## Supporting metrics
- [Metric 1]: [current value if known, target if known]
- [Metric 2]: [...]
- [Metric 3]: [...]

## Anti-features — things we explicitly will NOT build (with reasons)
- [Anti-feature 1] — [one-line reason]
- [Anti-feature 2] — [one-line reason]
- [Anti-feature 3] — [one-line reason]

## Brand voice (3–5 adjectives + 1 anti-adjective)
[adjective], [adjective], [adjective], [adjective] — never [anti-adjective].

## Platform
[iOS / Android / web / cross-platform / cross-platform with [framework]]

## Hard constraints
- Accessibility floor: [WCAG AA / WCAG AAA / none specified]
- Performance: [app size limit, cold-start budget, frame rate target]
- Offline: [which flows must work without network]
- Regulatory: [any specific compliance — GDPR, CCPA, MoC, FCC, etc.]
- Languages: [list, with primary]
```

---

## Worked example — Seqaya (Israeli plant-watering device)

```markdown
# Product context — Seqaya

## One-liner
Seqaya is a small NFC-paired hardware device that auto-waters one potted plant for
Israeli apartment-dwellers with balcony plants.

## Primary user
Israeli plant owner, 25–55, secular, tech-comfortable, lives in a Tel Aviv-area
apartment with a balcony or windowsill, owns 2–6 houseplants, has killed at least
one plant through neglect, travels 2–4 times per year. Speaks Hebrew primarily,
English fluently. Pragmatic, value-conscious, willing to spend on quality-of-life
upgrades but skeptical of "smart" gadgets.

## Top 3 jobs-to-be-done
1. "When I leave town, I want to know my plant won't die, so I can stop worrying
   about it during my trip."
2. "When I don't know if my plant needs water, I want a clear go/no-go signal
   without thinking, so I stop overwatering or under-watering."
3. "When my plant looks unwell, I want to know why and what to do, so I can save it."

## Current core flows
1. Provision: tap phone to device (NFC) → app captures wifi + plant target → device syncs.
2. Monitor: app home shows each plant's current moisture % and next-watering ETA.
3. Health alert: when a plant deviates from healthy band, push notification with
   one recommended action.

## Current IA
- Primary tabs: Plants | Notifications | (deliberately nothing else)
- Hidden in settings: account, device firmware, advanced thresholds, data export,
  language toggle
- Explicitly NOT in IA: no social feed, no plant marketplace, no in-app community

## North Star metric
% of plants alive at 30 days post-pairing. Target: ≥95%.

## Supporting metrics
- 30-day device retention (target ≥80%)
- Push-notification action-rate (target ≥40%)
- Support-tickets-per-active-device-per-month (target ≤0.05)
- App opens per device per week (target 3–5; higher suggests anxiety, lower suggests disengagement)

## Anti-features
- Cross-user plant social feed — pushes toward attention-economy patterns, conflicts
  with calm-utility brand.
- Multi-plant dashboards with graphs/charts in v1 — clutters the primary surface,
  small-multiples pattern reserved for v2.
- Voice control — adds a decision point (which voice assistant?) and a discovery
  problem, low frequency of use.
- HomeKit / Google Home integration before 10K devices — engineering cost too high
  for the addressable benefit at small scale.
- Gamification (badges, streaks, leaderboards) — contradicts "calm utility" positioning.

## Brand voice
warm, practical, slightly playful, never corporate — never apologetic.

## Platform
Android-first MVP, iOS in v2. Cross-platform via React Native.

## Hard constraints
- Accessibility floor: WCAG AA.
- App size: <30 MB initial install.
- Offline: Monitor flow must work without network (read last-cached state with a
  "last seen" timestamp). Provisioning flow may require network.
- Languages: Hebrew (primary), English (full parity). RTL/LTR aware throughout.
- Regulatory: MoC certification (Israel WiFi). FCC and CE deferred until US/EU expansion.
```

---

## Tips for writing your own

- **Specific beats abstract.** "Israeli plant owners 25–55 in apartments" beats "plant lovers." The skill's filters are sharper with sharper input.
- **JTBDs in user voice.** Always "When X, I want Y, so Z." If you can't write it that way, you don't have a JTBD yet — you have a feature wish.
- **Anti-features matter as much as features.** They're how the skill knows what to push back on.
- **Update it.** Product context changes. Re-run any open feature decisions against the updated context — the answer may flip.
