# Worked examples — good vs. bad output for each mode

Read this the first time you operate in each mode in a session, to anchor the output shape. After that, the SKILL.md contract is enough.

---

## REACTIVE mode

### Good — feature accepted, with reshaping

**User**: "Can we add a way for users to share their plant's progress on social media?"

**Response**:

Reshaping. Original framing is feature-led, not JTBD-led. Restated JTBD: "When my plant has grown noticeably, I want to share the proud moment with one person, so I feel celebrated without performing."

### Share plant progress

**JTBD**: When my plant has grown noticeably, I want to share the moment with one person, so I feel celebrated without performing.

**Filter results**:
1. JTBD: PASS — reshaped from "share on social media" to a real human moment.
2. Frequency: PASS-WITH-NOTE — ~1× per month per active user; tertiary surface.
3. Decision-burden: PASS — single tap to share, no choices required.
4. Defaults: PASS — defaults to OS share sheet, no settings exposed.
5. Replacement: PASS — fits inside long-press context menu, displaces nothing primary.
6. Krug no-think: PASS — long-press a plant card is a discovered gesture; no instruction needed.

**IA placement**:
- Surface tier: tertiary
- Specific location: long-press on a plant card → context menu, third item
- What it displaces: nothing on primary surface; the context menu gains one item

**Interaction model**:
- Entry: long-press on plant card → context menu → "Share progress"
- Primary action: opens native OS share sheet with a generated image (before/after photo + days since pairing)
- Decision points: zero (OS share sheet handles target selection)
- Error states: if no before-photo exists, share uses current photo + "Day N with my plant" caption
- Empty state: option is hidden if plant is < 7 days old (no growth yet to share)
- Success state: OS share sheet appears within 200ms

**Defaults**:
- Image template: side-by-side current/initial photo with days-since-pairing overlay — most universally appreciated format.
- Caption: editable, pre-filled with "Day N — my [plant name] is doing well 🌱" — light playfulness consistent with brand voice.

**Success metrics**:
- Leading: ≥3% of active users (≥7-day-old plants) tap "Share progress" within 30 days of feature release.
- Lagging: +2pp 90-day retention for users who shared at least once vs. matched cohort (correlation, not causation; track as a directional signal).

**Anti-features for this area**: no in-app social feed, no follower/leaderboard mechanics, no public plant profiles, no cross-posting integrations. These would push the product toward attention-economy patterns that conflict with the calm-utility positioning.

**Reference analogue**: Apple Photos' share-sheet — one entry point, OS handles distribution, no in-app social graph.

---

### Bad — what the agent must never do

**User**: "Can we add a way for users to share their plant's progress on social media?"

**Response (do NOT do this)**:

❌ "Great idea! Sharing is a powerful engagement mechanic. Here are 8 ways we could implement this: in-feed sharing, story sharing, native cross-posting, Instagram-first integration, TikTok video generation, weekly recap reels…"

**Why it's bad**: no JTBD, no filter results, sycophantic opener, surfaces 8 options when the right answer is 1, no IA placement, no anti-features, no reference analogue, treats user request as authoritative instead of running it through the protocol.

---

### Good — feature rejected at filter

**User**: "Let's add a settings page where users can configure the moisture thresholds per plant."

**Response**:

### Configure moisture thresholds per plant — REJECTED

**JTBD**: Restated attempt: "When I know my plant's specific needs better than the default, I want to set custom moisture thresholds, so it gets exactly the right amount of water." Possible, but not a strongly-held job for the typical user — most users do not know their plant's specific moisture preferences and would prefer the device to handle this for them.

**Filter results**:
1. JTBD: PASS-WITH-NOTE — exists, but only for a small expert minority.
2. Frequency: REJECT — set-once configuration, <1× per quarter per user.
3. Decision-burden: REJECT — adds 2 decisions (low threshold, high threshold), removes 0.
4. Defaults: REJECT — the device's self-calibrating HDR/DHR per plant is the default for everyone; exposing the override surfaces complexity the product is designed to hide.
5. Replacement: REJECT — adds a Settings screen with no displacement.
6. Krug no-think: REJECT — a new user seeing "Configure moisture thresholds" would not know what to set, would feel anxious, and would either abandon or copy a random value.

**Why this fails**: this is the textbook case of asking the user to do the product's job. The device's whole value proposition is "I figure out what your plant needs so you don't have to think." Adding a manual override contradicts the positioning.

**Better-shaped version**: if you have ~5% of users who legitimately want this (experienced houseplant enthusiasts), expose it via a hidden "Plant care mode" toggle in deep settings: `Advanced > Plant care mode > Manual` exposes the thresholds. Default is `Automatic`. This satisfies the long-tail without contaminating the primary experience.

**Reference analogue**: Apple's "Reduce Motion" — exists for a real minority, lives in Accessibility, never appears on primary surfaces.

---

## PROACTIVE mode

### Good

**User**: "What should we build next for Seqaya?"

**Response**:

Scanning product context: current JTBDs (vacation-survival, clear go/no-go signal, sickness diagnosis) are partially served by the current flows. The largest unserved gap is between the second and third JTBDs — there's no current flow for "my plant looks unwell, what's wrong?" beyond a notification that the device is in a fault state. Three candidates, ranked.

### 1. Diagnose a sick plant from a photo

**JTBD**: When my plant looks unwell (yellowing, drooping, brown spots), I want to know why and what to do, so I can save it.

**Filter results**:
1. JTBD: PASS — strongly-held, currently unserved.
2. Frequency: PASS — ~2× per month per active user (estimated from typical houseplant issues).
3. Decision-burden: PASS — one tap to start, one photo, one recommended action.
4. Defaults: PASS — fusion of Plant.id health endpoint + Gemini reasoning over moisture history; user doesn't choose models.
5. Replacement: PASS — replaces the current "something seems wrong" notification dead-end with an actionable flow.
6. Krug no-think: PASS — "Diagnose" button on a plant card is self-evident.

**IA placement**: primary surface — adds a "Diagnose" affordance to each plant card when the device flags an anomaly; otherwise tertiary (long-press → "Diagnose anyway").

**Interaction model**: tap "Diagnose" → camera opens → take photo → 2-second analysis → diagnosis + one recommended action + an option to auto-adjust moisture target if relevant.

**Defaults**: camera mode is single-photo; auto-adjust toggle is on; if confidence < 70%, offer "send to support" instead of guessing.

**Success metrics**:
- Leading: ≥40% of users who see an anomaly notification tap "Diagnose" within 30 days of release.
- Lagging: +5pp 90-day plant-survival rate for diagnosed plants vs. non-diagnosed plants in the same anomaly state.

**Anti-features for this area**: no chat-with-a-plant-expert flow (latency too high, support cost too high), no community Q&A (moderation cost too high, time-to-answer too slow).

**Reference analogue**: Apple Photos' "Look Up" for plants — single tap, instant result, optional deeper info.

### 2. Auto-pause watering during travel

(spec elided for brevity — full output-contract format would follow)

### 3. Multi-plant health dashboard

(spec elided for brevity)

**Ship #1 first.** Reasons: it's the only candidate that closes a currently-unserved JTBD (filter 1 strongest), it passes filter 6 with the strongest discoverability (a notification literally surfaces the affordance at the moment of need), and it has the cleanest leading metric — "tap-through rate on Diagnose" is observable within days of release, so we can kill it if it doesn't land. Candidates 2 and 3 are valuable but layer onto an existing experience rather than closing a gap.

---

### Bad — what the agent must never do in PROACTIVE mode

❌ "Here are some ideas to consider: a dashboard, gamification, social features, AI recommendations, voice commands, smart-home integrations, premium plant care content…"

**Why it's bad**: no ranking, no JTBD per item, protocol not applied, no recommendation, vague nouns instead of verb-phrase features, no metrics, no anti-features.

---

## AUDIT mode

### Good

**User**: "Audit the Seqaya home screen. Current state: a list of plant cards each showing photo + name + moisture %, a bell icon top-right for notifications, a + button bottom-right to add a plant."

**Response**:

### Audit findings — Home screen

**P0-1 — Missing system status for the device.**
- Principle violated: Nielsen heuristic 1 (visibility of system status).
- Specific location: plant card.
- Issue: showing only moisture % doesn't reveal whether the device is online, the battery state, or when it last reported. A user with a stale reading thinks the plant is fine when it might be — the system is hiding its own failure modes.
- Exact fix: add a small device-state badge to each card — green dot for "reporting normally", yellow for "last seen > 6h ago", red for "offline > 24h". Tappable for detail.

**P1-1 — Bell icon is a poor signifier for "notifications".**
- Principle violated: Norman's affordance/signifier mismatch + Nielsen heuristic 6 (recognition over recall).
- Specific location: top-right bell icon.
- Issue: notifications in this app are plant-state events, not communications. A user seeing a bell expects messages, not "your fern is dry."
- Exact fix: replace the bell with an inbox-style affordance ("Updates" pill with a number badge), or remove it entirely and route urgent items to the plant card itself (a card glows red when action is needed). Prefer the latter — it reduces a navigation step.

**P1-2 — Add-plant affordance competes for attention with primary content.**
- Principle violated: Krug "don't make me think" + Hick's Law.
- Specific location: bottom-right + button.
- Issue: a floating + button is a generic IoT-app pattern that signals "add another device" but doesn't reveal what's being added. For a user with 0 plants, this is the entire empty state's hint — too thin.
- Exact fix: empty state shows a prominent "Pair your first plant" CTA with a one-line explainer. Once any plants exist, the + button moves to the top app bar (Material 3 pattern) and uses the "add_circle" outlined icon with the label "Add plant" on first launch, icon-only after first use.

**P2-1 — Moisture percentage is data without meaning.**
- Principle violated: Tufte (data without context is noise) + Nielsen heuristic 2 (match to real world).
- Specific location: plant card moisture %.
- Issue: "62%" is a number without a reference frame — users don't know if 62% is good or bad for their specific plant.
- Exact fix: replace the bare percentage with a colored band indicator ("Just right" / "Slightly dry" / "Time to water" / "Overwatered") with the % as secondary info on tap. The band is the JTBD; the percentage is the supporting fact.

**P2-2 — No visible last-watered context.**
- Principle violated: Nielsen heuristic 1 (visibility of system status).
- Specific location: plant card.
- Issue: users want to know "when did this last get water?" to build trust in the device. The data exists but isn't surfaced.
- Exact fix: add a small "Last watered: 3 days ago" line below the plant name. Updates whenever the valve fires.

---

### Bad — what the agent must never do in AUDIT mode

❌ "The home screen looks clean and intuitive. Consider improving accessibility, ensuring good contrast, and making sure the layout is responsive across devices."

**Why it's bad**: no specific findings, no principles named, no severity, no exact fixes, vague boilerplate that could apply to any screen, sycophantic opener.

---

## The pattern across all three modes

- **Always name the principle** (specific Nielsen heuristic, specific Krug rule, specific JTBD)
- **Always state the exact fix or exact next action**, not "consider improving X"
- **Always show what gets displaced** when something is added
- **Reject directly when a filter fails** — naming which filter and why
- **No preamble, no sycophancy** ("Great question!", "I love this idea!")
- **One reference analogue per major spec** — a real shipped pattern users already understand
