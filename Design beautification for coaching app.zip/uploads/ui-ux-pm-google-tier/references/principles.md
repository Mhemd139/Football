# Named principles reference

Read this when you need to invoke a specific framework by name and the SKILL.md summary isn't enough.

## Steve Krug — "Don't Make Me Think"

Three laws:
1. **Don't make me think.** Every page/screen should be self-evident — obvious, self-explanatory. If a user has to think about what something does or where it leads, the design has failed.
2. **It doesn't matter how many times I have to click, as long as each click is a mindless, unambiguous choice.** Click counts are secondary; cognitive load is primary.
3. **Get rid of half the words on each page, then get rid of half of what's left.** Most copy is filler. Strip it.

Practical application: if explaining a UI element requires a tooltip, the affordance is wrong. Redesign the element, don't add a tooltip.

## Don Norman — affordances and signifiers

- **Affordance** — what an object permits a user to do. A door handle affords pulling; a flat plate affords pushing.
- **Signifier** — the visible cue that tells the user the affordance exists. A "PUSH" label on a flat plate is a signifier.
- **Mental model** — how the user thinks the system works.
- **Conceptual model** — how the system actually works.
- **Design model** — what the designer intended the user to perceive.

Good design closes the gap: design model → signifier → user's mental model → action → conceptual model behaves as expected. Bad design opens a gap anywhere in that chain.

Practical application: if users repeatedly "click the wrong thing," the signifier is misleading them about the affordance. Fix the cue, not the user.

## Jakob Nielsen — 10 Usability Heuristics

Use these in AUDIT mode as the criteria for findings. Each finding should reference the specific heuristic violated.

1. **Visibility of system status.** Users should know what's happening (loading indicators, progress, current state).
2. **Match between system and the real world.** Use the user's language, not engineering jargon. Follow real-world conventions.
3. **User control and freedom.** Provide undo, cancel, back. Don't trap users in flows.
4. **Consistency and standards.** Same patterns mean the same things across the app and the platform.
5. **Error prevention.** Design constraints that prevent the error rather than just handling it well after.
6. **Recognition rather than recall.** Show available actions; don't require the user to remember them from elsewhere.
7. **Flexibility and efficiency of use.** Power users get shortcuts; novices get hand-holding. Both work.
8. **Aesthetic and minimalist design.** Every element earns its place. Anything that doesn't, leaves.
9. **Help users recognize, diagnose, and recover from errors.** Plain language, specific causes, suggested fixes.
10. **Help and documentation.** Searchable, focused on the user's task, with concrete steps.

## Google Material 3

Key principles relevant to product decisions (not visual styling specifics):

- **Adaptive.** The same product feels native on phone, tablet, watch, foldable. Layouts respond to size class, not device name.
- **Expressive but restrained.** Color, motion, and shape carry meaning. Use them to encode hierarchy and state, not to decorate.
- **Motion has purpose.** Animations communicate relationships (where things came from, where they go). Motion that doesn't carry information is noise.
- **Color tokens, not raw colors.** Use semantic color roles (primary, on-primary, surface-container, error) so themes adapt cleanly.

For Seqaya-style consumer apps, the most load-bearing Material 3 lessons are: dynamic color (the app picks up the user's theme), large-tap-target consistency (48dp minimum), and motion as state-transition narrator.

## Google PM playbook — core frameworks

### JTBD (Jobs to Be Done)

A user "hires" a feature to do a job. Frame every feature in user-voice, in a "When [situation], I want [motivation], so [outcome]" structure. Example: "When I leave town, I want to know my plant won't die, so I can stop worrying."

Anti-pattern: framing features as nouns ("a notifications system") or as solutions ("we should add Bluetooth"). Both skip the job and design for the tool instead of the user.

### RICE prioritization

Score every feature on:
- **Reach** — how many users will it touch in a given window? (number or percentage)
- **Impact** — how much will it improve the metric for each user? (0.25 / 0.5 / 1 / 2 / 3 scale)
- **Confidence** — how sure are you of the reach and impact estimates? (50% / 80% / 100%)
- **Effort** — person-months to ship

Score = (Reach × Impact × Confidence) / Effort. Higher score = ship first.

In your specs, you don't need to compute RICE numerically — but the spec should make clear what each component is for that feature, so the user can reason about prioritization.

### North Star Metric

One single number that captures the value delivered. Should be a leading indicator of long-term success, not a vanity metric. Examples:
- Airbnb: nights booked
- Spotify: time spent listening
- Slack: messages sent inside paid teams
- (Seqaya analog: % of plants alive at 30 days post-pairing)

Every feature spec should explain how the feature moves the North Star, or why it's a necessary supporting move that doesn't directly move it.

### Kill bad features fast

A shipped feature is not permanent. If 30-day adoption is below threshold (typically <5% of active users), kill it or hide it. Carrying dead features taxes every future design decision (you have to consider whether they break) and steals attention.

The decision protocol's filter 5 (Replacement) is the inverse of this — what's the dying feature that this new one displaces? If nothing's dying, you're adding without removing, which means the product gets worse, not better.

## Edward Tufte — data-ink and chartjunk

Tufte's framework is about data visualization but generalizes to UI:
- **Data-ink ratio** — what fraction of pixels carry information? Maximize it.
- **Chartjunk** — decorative pixels that don't carry information. Eliminate it.
- **Small multiples** — show variation by repeating a small chart with different data, not by adding axes and legends.

UI application: every visual element on a screen should encode either information (what's the data?), state (what's happening now?), or affordance (what can I do?). Anything that's pure decoration is chartjunk. Strip it.

## Hick's Law — choice and time

Decision time grows logarithmically with the number of choices. Practical rule used in this skill: **no more than 5 primary actions on any single screen** as a default. Exceed it only with explicit justification.

The right design pattern when you have many possible actions: primary surface shows the top 1–3, secondary surface (menu, sheet, drawer) holds the rest, organized by frequency. Gmail's UI is the canonical example — 5 visible actions, dozens behind a `⋮`.

## Fitts's Law — target size and distance

Time to acquire a target = a + b × log₂(distance / size + 1). Practical implications:
- Bigger touch targets are faster (the 48dp minimum exists for this reason).
- Targets at screen edges/corners are effectively infinite-sized (you can throw the cursor there). This is why macOS puts the menu bar at the top edge.
- The currently-focused area is the cheapest place to put the next action.

Use these when arguing about target placement and size in specs.

## Why these frameworks specifically

Grounding the persona in specific named frameworks (rather than "you are a world-class UX expert") preserves the alignment benefits of persona prompting (writing quality, format adherence) without triggering the factual-recall penalty that generic expert personas cause. See Wharton GAIL "Playing Pretend" (Dec 2025) and PRISM (arXiv 2603.18507, 2026).
